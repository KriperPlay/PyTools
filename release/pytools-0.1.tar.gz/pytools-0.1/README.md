# How to use

* Logging
* * Class Logging:
  * * TimeLog(self,func,Lines,*args,**kwargs) - func(func),Lines(choice option: "Line" - just Line where error; "Lineno" - just line number where error; "Line&no" - line and line number where error)
    * FullLog(self,func) - just full log of error
    * TimeLogWrite(self,func,Lines:str,file:str,*args, **kwargs) - same TimeLog, but writing in file 'file'
    * DictLog(self,func,*args, **kwargs) - same TimeLog, but return dictionary
    * JsonLog(self,func,file,*args,**kwargs) - same DictLog, but writing in json file 'file'
* * Class InfoFunc:
  * * InfoFunc(func,file) - example: InfoFunc(plus,__file__)
    * InfoFunc(func,file).doc - doc of func
    * InfoFunc(func,file).callable - is the function callable?
    * InfoFunc(func,file).code - source code func
    * InfoFunc(func,file).func_name - name of func
    * InfoFunc(func,file).annot - annotations of func
    * InfoFunc(func,file).args - default args of func
    * InfoFunc(func,file).param_names - names of all args of func
* * Class Testing:
  * * assertt(self,result,func: callable,*args,**kwargs) - ('result' - necessary result of func) simple unittest
    * print_test(self) - printing tests with colors and which test for which function
    * simple_tests(self) - just printing tests
* * Decorators:
  * * @logging_full - same Logger().FullLog(), but decorator and printing straightaway
    * @logging - same Logger.TimeLog(), but decorator and printing straightaway
    * @logging_to_file(file) - same Logger.TimeLogWrite(), but decorator
